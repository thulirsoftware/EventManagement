<!DOCTYPE html>
<html lang="en">

<body>
	
<p style="text-align:left;font-weight:bold"> Dear Registrant,</p>
<p style="text-align:left">Greetings from New England Tamil Sangam!!!</p><br>
<p style="text-align:left">Thanks for providing essential details for NETS registration.</p><br>
<p style="text-align:left">Please verify your email to proceed further.</p><br>
 	<div class="button_container" style="text-align:center">
 	 	<a class="view_detail_button" href="{{config('app.url')}}verify/{{$details['email']}}/{{$details['token']}}" target="_blank"
 	  style="text-align: center; padding: 10px 15px; background: #3b5998; border-radius: 10px; margin: 0; color: white;"> Verify Email </a>
     </div><br>
<span>Regards</span><br>
<span>NETS</span><br>
</body>

</html> 