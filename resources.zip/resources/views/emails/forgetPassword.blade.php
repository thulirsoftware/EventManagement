<h4><center>Reset Password</center></h4>
<p>You are receiving this email because we received a password reset request for your account.</p>
<p>You can reset password from bellow link</p><br>
<div class="button_container" style="text-align:center">
<a href="{{ route('reset.password.get', $token) }}" target="_blank"  style="text-align: center; padding: 10px 15px; background: #3b5998; border-radius: 10px; margin: 0; color: white;">Reset Password</a>
</div>
<p>If you did not request a password reset, no further action is required.</p>