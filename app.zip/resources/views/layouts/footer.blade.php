<footer class="main-footer">
    <strong>Copyright &copy; 2020 <a href="#">Thulirsoft</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
    </div>
  </footer>